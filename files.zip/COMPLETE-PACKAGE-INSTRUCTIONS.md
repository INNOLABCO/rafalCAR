# 🚗 RAFAL CAR - COMPLETE WEBSITE PACKAGE

## ✅ WHAT'S INCLUDED:

### **MAIN FILES (3):**
1. ✅ `index.html` - Main homepage with ALL 16 cars from Excel
2. ✅ `styles.css` - Same design, RTL support added
3. ✅ `script.js` - Multi-language + form backend

### **INDIVIDUAL CAR PAGES (16):**
Each car from your Excel gets its own detail page:
- car-hyundai-tucson.html
- car-dacia-logan.html
- car-peugeot-208.html
- car-opel-corsa.html
- car-renault-express.html
- car-skoda-karoq.html
- car-volkswagen-touareg.html
- car-cupra-formentor.html
- car-renault-clio.html
- car-hyundai-accent.html
- car-mercedes-s-class.html
- car-mercedes-cla.html
- car-mercedes-c-class.html
- car-range-rover-sport.html
- car-range-rover-velar.html
- car-range-rover-evoque.html

### **GOOGLE ADS LANDING PAGES (4):**
1. ✅ `economy-cars.html` - Only budget cars (270-340 MAD)
2. ✅ `luxury-cars.html` - Only premium cars (900-4000 MAD)
3. ✅ `suv-rental.html` - Only SUVs (500 MAD)
4. ✅ `thank-you.html` - After form submission

### **EXTRA FILES:**
- `cars-data.json` - Database of all 16 cars
- `README.md` - Documentation

**TOTAL: 27 FILES**

---

## 🎯 WHAT CHANGED:

### ✅ BRAND:
- "Mester Car" → "RAFAL CAR" (everywhere)
- Logo text updated
- Footer updated
- Meta tags updated

### ✅ CARS:
- 16 real cars from your Excel
- All 2024 models
- Real prices & deposits
- Proper categorization
- Individual detail pages

### ✅ LANGUAGES:
- English ✅
- French ✅
- Arabic ✅ (with RTL)
- Language switcher in navbar
- Saves user preference

### ✅ FEATURES:
- Form backend (Formspree ready)
- Google Ads landing pages
- Thank you page
- Multi-language
- Mobile responsive
- WhatsApp integration

### ✅ DESIGN:
- **SAME DESIGN** - no changes!
- Same colors
- Same layout
- Same animations
- Just enhanced functionality

---

## 📦 YOUR 16 CARS (FROM EXCEL):

### **ECONOMY (6 cars):**
1. Dacia Logan - 270 MAD/day - Deposit: 5,000 MAD
2. Peugeot 208 - 300 MAD/day - Deposit: 5,000 MAD
3. Opel Corsa - 300 MAD/day - Deposit: 5,000 MAD
4. Renault Clio 5 - 300 MAD/day - Deposit: 5,000 MAD
5. Hyundai Accent - 300 MAD/day - Deposit: 5,000 MAD
6. Renault Express - 340 MAD/day - Deposit: 5,000 MAD

### **SUV (3 cars):**
1. Hyundai Tucson - 500 MAD/day - Deposit: 10,000 MAD
2. Skoda Karoq - 500 MAD/day - Deposit: 5,000 MAD
3. Cupra Formentor - 500 MAD/day - Deposit: 5,000 MAD

### **LUXURY (7 cars):**
1. Volkswagen Touareg - 900 MAD/day - Deposit: 5,000 MAD
2. Range Rover Evoque - 1,200 MAD/day - Deposit: 20,000 MAD
3. Mercedes CLA - 1,400 MAD/day - Deposit: 20,000 MAD
4. Mercedes C-Class - 1,500 MAD/day - Deposit: 20,000 MAD
5. Range Rover Velar - 1,500 MAD/day - Deposit: 20,000 MAD
6. Range Rover Sport - 3,500 MAD/day - Deposit: 20,000 MAD
7. Mercedes S-Class - 4,000 MAD/day - Deposit: 20,000 MAD

**All models: 2024** ✅

---

## 🚀 HOW TO DEPLOY:

### **STEP 1: Download All Files**
I'm creating all files in /mnt/user-data/outputs/

### **STEP 2: Update Your Contact Info**
Find and replace in ALL files:
- Phone: `212662186949` → Your WhatsApp
- Email: `rafal.carmed5@gmail.com` → Your email

### **STEP 3: Setup Form Backend (Optional)**
If you want email notifications:
1. Go to https://formspree.io
2. Sign up (free)
3. Create form
4. Get Form ID
5. In `script.js`, replace `YOUR_FORM_ID` with your actual ID

**OR** keep WhatsApp integration (already working!)

### **STEP 4: Upload to GitHub**
1. Go to your GitHub: github.com/INNOLABCO/mestercar-website
2. Delete ALL old files
3. Upload ALL new files (27 files)
4. Commit changes

### **STEP 5: Vercel Auto-Deploys**
- Vercel detects changes
- Auto-deploys in 30 seconds
- Your site is live!

### **STEP 6: Test Everything**
✅ Main page loads
✅ All 16 cars show
✅ Language switcher works
✅ Individual car pages open
✅ Contact form works
✅ Landing pages work
✅ Mobile version works

---

## 🌍 LANGUAGE SWITCHER:

### **How to Use:**
1. Look for language dropdown in navbar
2. Click to see: English | Français | العربية
3. Select language
4. Page translates instantly
5. Choice is saved

### **What's Translated:**
- Navigation menu
- Hero section
- Search box
- Features
- Buttons
- Car details
- Footer

### **Arabic Support:**
- Right-to-left layout
- Arabic font
- Proper text alignment

---

## 📄 LANDING PAGES USAGE:

### **For Google Ads:**

**Campaign 1: Budget Cars**
- URL: `yourdomain.com/economy-cars.html`
- Keywords: "cheap car rental morocco"
- Shows only: Economy cars

**Campaign 2: Luxury Cars**
- URL: `yourdomain.com/luxury-cars.html`
- Keywords: "luxury car rental morocco"
- Shows only: Luxury cars

**Campaign 3: SUV Rental**
- URL: `yourdomain.com/suv-rental.html`
- Keywords: "suv rental morocco"
- Shows only: SUVs

**After Submission:**
- URL: `yourdomain.com/thank-you.html`
- Shows: Thank you message
- Action: Redirect to WhatsApp

---

## 💰 COSTS:

Everything is **100% FREE:**
- ✅ Hosting: Vercel (FREE)
- ✅ Form Backend: Formspree (50/month FREE)
- ✅ Multi-language: Built-in (FREE)
- ✅ All pages: Static HTML (FREE)
- ✅ Updates: As needed (FREE)

**Only cost:** Google Ads (you control budget)

---

## 📁 FILE STRUCTURE:

```
rafal-car-website/
├── index.html (Main page - Rafal Car)
├── styles.css (Same design)
├── script.js (Multi-language)
├── cars-data.json
├── README.md
├── 
├── Individual Cars (16 files):
├── car-hyundai-tucson.html
├── car-dacia-logan.html
├── car-peugeot-208.html
├── ... (13 more)
├── 
├── Landing Pages (4 files):
├── economy-cars.html
├── luxury-cars.html
├── suv-rental.html
├── thank-you.html
```

---

## ✅ QUICK CHECKLIST:

Before going live:
- [ ] Download all 27 files
- [ ] Update phone number in all files
- [ ] Update email in all files
- [ ] Upload to GitHub
- [ ] Wait for Vercel to deploy
- [ ] Test main page
- [ ] Test 2-3 car pages
- [ ] Test language switcher
- [ ] Test contact form
- [ ] Test on mobile
- [ ] Setup Google Ads (optional)

---

## 🆘 NEED HELP?

**File locations:**
All files are in: `/mnt/user-data/outputs/`

**To update contact info:**
Use Find & Replace:
- Find: `212662186949`
- Replace: Your number

**To add more cars later:**
1. Add to `cars-data.json`
2. Create car detail page (copy template)
3. Update index.html

**Questions?**
Just ask! I'm here to help! 🚀

---

## 🎉 YOU'RE READY!

Everything is prepared. Just:
1. Download files
2. Update contact info
3. Upload to GitHub
4. Go live!

**Your professional Rafal Car website with 16 cars, multi-language, and landing pages is ready to launch! 🚗💨**
